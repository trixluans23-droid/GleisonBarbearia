GLEISON BARBEARIA - PROJETO ANDROID

Base: Gleison_Barbearia_2a_versao_R35.html
Preço do Corte: R$ 35,00

Este projeto empacota o HTML como aplicativo Android usando WebView.

Para gerar o APK, é necessário um ambiente de build Android (por exemplo, GitHub Actions ou Android Studio).
